package hlju.demo;

import hlju.demo.R;
import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class sub1Activity extends Activity{
	EditText editText;
	Button buttonok,buttoncancel;
	   @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.sub1);
	        editText=(EditText)findViewById(R.id.sub1editText);
	        buttonok=(Button)findViewById(R.id.sub1button1);
	        buttoncancel=(Button)findViewById(R.id.sub1button2);
	        buttonok.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
				    Uri data=Uri.parse(editText.getText().toString());
			        Intent result = new Intent(null,data);
			        setResult(Activity.RESULT_OK, result);
			        finish();
				}
			});
	        buttoncancel.setOnClickListener(new View.OnClickListener() {
				
				public void onClick(View v) {
					// TODO Auto-generated method stub
				
			        setResult(Activity.RESULT_CANCELED, null);
			        finish();
				}
			});
	    
	    }
}

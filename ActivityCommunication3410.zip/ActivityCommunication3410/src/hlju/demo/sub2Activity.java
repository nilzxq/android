package hlju.demo;

import hlju.demo.R;
import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class sub2Activity extends Activity{
	Button button;
	   @Override
	    public void onCreate(Bundle savedInstanceState) {
	        super.onCreate(savedInstanceState);
	        setContentView(R.layout.sub2);
	        button=(Button)findViewById(R.id.sub2button);
	        button.setOnClickListener(new View.OnClickListener() {
				
					public void onClick(View v) {
						// TODO Auto-generated method stub
					
				        setResult(Activity.RESULT_CANCELED, null);
				        finish();
					}
				});
	    }
}

package hlju.edu.BroadcastReceiverDemo3410;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class BroadcastReceiverDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	EditText myText;
	Button btn;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        myText=(EditText)findViewById(R.id.myText);
        btn=(Button)findViewById(R.id.btnBroad);
        btn.setOnClickListener(new View.OnClickListener(){

			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent=new Intent("hlju.edu.BroadcastReceiverDemo3410");
			    intent.putExtra("message",myText.getText().toString());
			    sendBroadcast(intent);
			}
        	
        });
    }
}
package hlju.edu.Button01Demo3410;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class Button01Demo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView user,password;
	EditText euser,epassword;
	Button login,cancle;
	TextView result;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        user=(TextView)findViewById(R.id.textUser);
        user.setText("�û�����");
        euser=(EditText)findViewById(R.id.editUser);
        password=(TextView)findViewById(R.id.textPassword);
        password.setText("���룺");
        epassword=(EditText)findViewById(R.id.editPassword);
        login=(Button)findViewById(R.id.buttonLogin);
        login.setText("��¼");
        cancle=(Button)findViewById(R.id.buttonCancle);
        cancle.setText("ȡ��");
        result=(TextView)findViewById(R.id.textLogin);
        Button.OnClickListener buttonListener=new Button.OnClickListener(){

			public void onClick(View v) {
				// TODO Auto-generated method stub
				switch(v.getId()){
				case R.id.buttonLogin:
					result.setText("��¼�ɹ���");break;
				case R.id.buttonCancle:
					result.setText("ȡ����¼��");break;
				}
			}
        	
        };
        login.setOnClickListener(buttonListener);
        cancle.setOnClickListener(buttonListener);
    }
}
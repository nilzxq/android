package hlju.edu.Button02Demo3410;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;

public class Button02Demo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView text;
	ImageButton image;
	Button change;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        text=(TextView)findViewById(R.id.text);
        text.setText("");
        image=(ImageButton)findViewById(R.id.imageButton);
        image.setImageResource(R.drawable.iconempty);
        change=(Button)findViewById(R.id.change);
        change.setText("����л�ͼƬ");
        change.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(v.dispatchTouchEvent(null)){
					image.setImageResource(R.drawable.iconfull);
					text.setText("�����ɹ�");
				}
			}
		});
    }
}
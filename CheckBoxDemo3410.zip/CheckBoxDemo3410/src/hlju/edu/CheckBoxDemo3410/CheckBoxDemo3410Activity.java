package hlju.edu.CheckBoxDemo3410;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.TextView;

public class CheckBoxDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView question,result;
	CheckBox basketball,football,ping,volleyball;
	Button submit;
	int t;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        question=(TextView)findViewById(R.id.question);
        result=(TextView)findViewById(R.id.result);
        basketball=(CheckBox)findViewById(R.id.basketball);
        football=(CheckBox)findViewById(R.id.football);
        ping=(CheckBox)findViewById(R.id.ping);
        volleyball=(CheckBox)findViewById(R.id.volleyball);
        submit=(Button)findViewById(R.id.submit);
        CheckBox.OnCheckedChangeListener checkbox=new CheckBox.OnCheckedChangeListener(){

			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				if(isChecked)
				t++;
				else t--;
				
			}
        	
        };
        basketball.setOnCheckedChangeListener(checkbox);
        football.setOnCheckedChangeListener(checkbox);
        ping.setOnCheckedChangeListener(checkbox);
        volleyball.setOnCheckedChangeListener(checkbox);
        submit.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				result.setText("лл���룡��һ��ѡ����"+t+"��");
			}
		});
        t=0;
    }
    }
  
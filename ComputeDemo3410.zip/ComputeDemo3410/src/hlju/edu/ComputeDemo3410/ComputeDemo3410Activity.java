package hlju.edu.ComputeDemo3410;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class ComputeDemo3410Activity extends Activity {
	EditText factor1,factor2;
	Button compute;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        factor1=(EditText)findViewById(R.id.factor1);
        factor2=(EditText)findViewById(R.id.factor2);
       compute=(Button)findViewById(R.id.compute);
       compute.setOnClickListener(new View.OnClickListener() {
		
		public void onClick(View v) {
			// TODO Auto-generated method stub
			String str1=factor1.getText().toString();
			String str2=factor1.getText().toString();
			Intent intent=new Intent(ComputeDemo3410Activity.this,SubActivity.class);
			intent.putExtra("one",str1);
			intent.putExtra("two",str2);
			startActivity(intent);
		}
	});
    }
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		menu.add(0,1,1,R.string.exit);
		menu.add(0,1,1,R.string.about);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		if(item.getItemId()==1){
			finish();
		}
		return super.onOptionsItemSelected(item);
	}

     
}
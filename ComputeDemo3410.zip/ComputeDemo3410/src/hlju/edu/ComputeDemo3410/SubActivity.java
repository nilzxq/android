package hlju.edu.ComputeDemo3410;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class SubActivity extends Activity{
   TextView resultText;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sub);
		resultText=(TextView)findViewById(R.id.result);
		Intent intent=getIntent();
		String factor1=intent.getStringExtra("one");
		String factor2=intent.getStringExtra("two");
		int factor1Int=Integer.parseInt(factor1);
		int factor2Int=Integer.parseInt(factor2);
		int result=factor1Int*factor2Int;
		resultText.setText(result+"");
	}
	
}

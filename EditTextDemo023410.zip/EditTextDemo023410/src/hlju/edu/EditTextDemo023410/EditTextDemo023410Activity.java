package hlju.edu.EditTextDemo023410;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class EditTextDemo023410Activity extends Activity {
    /** Called when the activity is first created. */
	
	TextView myText1,myText2;
	EditText myEdit1;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        myText1=(TextView)findViewById(R.id.MyTextView01);
        myText1.setText("�û���");
        myEdit1=(EditText)findViewById(R.id.MyEditText01);
        myText2=(TextView)findViewById(R.id.MyTextView02);
        
        myEdit1.setOnKeyListener(new View.OnKeyListener() {
			
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				myText2.setText(myEdit1.getText());
				return false;
			}
		});
        
}
}
package hlju.edu.EditTextDemo3410;

import android.app.Activity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;

public class EditTextDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView myText1;
	TextView myText2;
	EditText myEdit1;
	EditText myEdit2;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        myText1=(TextView)findViewById(R.id.MyTextView01);
        myText1.setText("�û���");
        myEdit1=(EditText)findViewById(R.id.MyEditText01);
        
        myText2=(TextView)findViewById(R.id.MyTextView02);
        myText2.setText("����");
        myEdit2=(EditText)findViewById(R.id.MyEditText02);
}
}
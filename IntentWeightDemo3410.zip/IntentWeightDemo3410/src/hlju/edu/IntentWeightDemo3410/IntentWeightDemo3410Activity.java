package hlju.edu.IntentWeightDemo3410;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;

public class IntentWeightDemo3410Activity extends Activity {
	RadioGroup gender;
	RadioButton sex_choose;
	EditText editHeight;
	Button compute;
    String sex;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        gender=(RadioGroup)findViewById(R.id.radioGroup);
        editHeight=(EditText)findViewById(R.id.editHeight);
        compute=(Button)findViewById(R.id.compute);
    	gender.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				// TODO Auto-generated method stub
				sex_choose=(RadioButton)findViewById(gender.getCheckedRadioButtonId());
				sex=sex_choose.getText().toString();
			}	
		});
		
        compute.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				String height=editHeight.getText().toString();
				Intent intent=new Intent(IntentWeightDemo3410Activity.this,ShowActivity.class);
				Bundle bundle=new Bundle();
				bundle.putString("sex",sex);
				bundle.putString("height",height);
				intent.putExtras(bundle);
				startActivity(intent);
			}
		});    	
    }
}
package hlju.edu.IntentWeightDemo3410;


import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class ShowActivity extends Activity{
	  TextView showView;
	  double weight;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.show);
		showView=(TextView)findViewById(R.id.show);
		Bundle bundle=getIntent().getExtras();
		String height=bundle.getString("height");
	  	String  sex=bundle.getString("sex");
	  	double Height=Double.valueOf(height).doubleValue();
	  	if(sex=="woman")
	  		weight=(Height-70)*0.6;
	  	else
	  		weight=(Height-80)*0.7;
	  	
		  showView.setText("你是一位"+sex+"\n"+"你的身高是"+height+"厘米\n"+"你的标准体重是"+weight+"公斤");	
	}
	

}

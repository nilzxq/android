package hlju.edu.List02Demo3410;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.app.ListActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

public class List02Demo3410Activity extends ListActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        ArrayList<HashMap<String,String>> list=new ArrayList<HashMap<String,String>>();
        HashMap<String,String> mp1=new HashMap<String,String>();
        HashMap<String,String> mp2=new HashMap<String,String>();
        HashMap<String,String> mp3=new HashMap<String,String>();
        mp1.put("user_name","zhangsa");
        mp1.put("user_ip","192.168.0.1");
        mp2.put("user_name","lisi");
        mp2.put("user_ip","192.168.0.2");
        mp3.put("user_name","wangwu");
        mp3.put("user_ip","192.168.0.3");
        list.add(mp1);
        list.add(mp2);
        list.add(mp3);
        SimpleAdapter listAdapter=new SimpleAdapter(this,list,R.layout.user,
        		new String[]{"user_name","user_ip"},
        		new int[]{R.id.userName,R.id.userIp});
        setListAdapter(listAdapter);
    }

	@Override
	protected void onListItemClick(ListView l, View v, int position, long id) {
		// TODO Auto-generated method stub
		super.onListItemClick(l, v, position, id);
		Toast.makeText(this,"You click:"+position,Toast.LENGTH_LONG).show();
	}
    
}
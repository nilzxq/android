package hlju.edu.MathserviceDemo3410;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.widget.Toast;

public class Mathsercice extends Service{

	public final IBinder mBinder = (IBinder) new LocalBinder();
	
	public class LocalBinder extends Binder
	{
		Mathsercice getService()
		{
			return Mathsercice.this;
		}
	}
	
	
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(this, "本地绑定：MathService", Toast.LENGTH_LONG).show();
		return mBinder;
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		Toast.makeText(this, "取消本地绑定：MathService", Toast.LENGTH_LONG).show();
		return false;
	}
	public long Add(long a,long b)
	{
		return a+b;
		
	}

}

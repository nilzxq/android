package hlju.edu.MathserviceDemo3410;

import hlju.edu.MathserviceDemo3410.Mathsercice;
import hlju.edu.MathserviceDemo3410.MathserviceDemo3410Activity;
import hlju.edu.MathserviceDemo3410.R;
import android.app.Activity;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MathserviceDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	private Mathsercice mathservice;
	private boolean isBound=false;
	private TextView mytext;
	private Button btnBind,btnUnBind,btnAdd;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mytext = (TextView)findViewById(R.id.mytext);
        btnBind = (Button)findViewById(R.id.bind);
        btnUnBind = (Button)findViewById(R.id.unbind);
        btnAdd = (Button)findViewById(R.id.add);
        btnBind.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(!isBound)
				{
					final Intent serviceIntent = new Intent(MathserviceDemo3410Activity.this,Mathsercice.class);
					bindService(serviceIntent,mConnection,Context.BIND_AUTO_CREATE);
					
				}				
				isBound= true;
			}
		});
        btnUnBind.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(isBound)
				{
					isBound=false;
					unbindService(mConnection);
					mathservice = null;
				}
				
			}
		});
        
        btnAdd.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(mathservice==null)
				{
					mytext.setText("未绑定服务");
					return;
				}
				long a=Math.round(Math.random()*100);
				long b=Math.round(Math.random()*100);
				long result = mathservice.Add(a, b);
				String msg = String.valueOf(a)+"+"+String.valueOf(b)+"="+String.valueOf(result);
				mytext.setText(msg);
			}
		});
        
  
    }
    
    private ServiceConnection mConnection = new ServiceConnection(){

		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			mathservice = ((Mathsercice.LocalBinder)service).getService();
		}

		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			mathservice=null;
		}
    	
    };
    
}
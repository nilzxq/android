package hlju.edu.PreferenceDemo3410;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.EditText;

public class PreferenceDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	EditText txtName,txtAge,txtHeight;
	String PREFERENCE_NAME="SaveSetting";
	int MODE=Context.MODE_WORLD_READABLE+Context.MODE_WORLD_WRITEABLE;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        txtName=(EditText)findViewById(R.id.name);
        txtAge=(EditText)findViewById(R.id.age);
        txtHeight=(EditText)findViewById(R.id.height);
    }
	@Override
	protected void onStart() {
		// TODO Auto-generated method stub
		super.onStart();
		loadSharedPreferences();
	}
	@Override
	protected void onStop() {
		// TODO Auto-generated method stub
		super.onStop();
		saveSharedPreferences();
	}
	
	private void loadSharedPreferences() {
      SharedPreferences sharePreferences=getSharedPreferences(PREFERENCE_NAME,MODE);		
	  String name=sharePreferences.getString("Name", "Tom");
	  int age=sharePreferences.getInt("Age", 20);
	  float height=sharePreferences.getFloat("Height",1.81f);
	  txtName.setText(name);
	  txtAge.setText(String.valueOf(age));
	  txtHeight.setText(String.valueOf(height));
	  
	}
	private void saveSharedPreferences() {
		// TODO Auto-generated method stub
		 SharedPreferences sharePreferences=getSharedPreferences(PREFERENCE_NAME,MODE);		
	     SharedPreferences.Editor editor=sharePreferences.edit();
	     editor.putString("Name", txtName.getText().toString());
	     editor.putFloat("Height", Float.parseFloat(txtHeight.getText().toString()));
	     editor.commit();
	}
}
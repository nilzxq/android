package hlju.edu.ProgressBarDemo3410;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class ProgressBarDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
	ProgressBar firstBar=null,secondBar=null;
	Button button;
	int i=0;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        firstBar=(ProgressBar)findViewById(R.id.firstBar);
        secondBar=(ProgressBar)findViewById(R.id.secondBar);
        button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener(){

			public void onClick(View v) {
				// TODO Auto-generated method stub
				if(i==0){
					firstBar.setVisibility(View.VISIBLE);
					firstBar.setMax(150);
					secondBar.setVisibility(View.VISIBLE);
					secondBar.setMax(150);
				}else if(i<firstBar.getMax()){
					firstBar.setProgress(i);
					firstBar.setSecondaryProgress(i+10);
					secondBar.setProgress(i);
				}else{
					firstBar.setVisibility(View.GONE);
					secondBar.setVisibility(View.GONE);
				}
				i+=10;
			}});
    }
}
package hlju.edu.RadioButton02Demo3410;

import android.app.Activity;
import android.os.Bundle;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;

public class RadioButton02Demo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView question;
    RadioGroup group;
    RadioButton Sh,Cq,Wh,Gz;
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        question=(TextView)findViewById(R.id.question);
        group=(RadioGroup)findViewById(R.id.group);
        Sh=(RadioButton)findViewById(R.id.Sh);
        Cq=(RadioButton)findViewById(R.id.Cq);
        Wh=(RadioButton)findViewById(R.id.Wh);
        Gz=(RadioButton)findViewById(R.id.Gz);
        
        group.setOnCheckedChangeListener(radioListener);
    }
    
    private RadioGroup.OnCheckedChangeListener radioListener=new RadioGroup.OnCheckedChangeListener() {
		
		public void onCheckedChanged(RadioGroup group, int checkedId) {
			// TODO Auto-generated method stub
			if(checkedId==Sh.getId()){
				question.setText(Sh.getText());
			}else if(checkedId==Cq.getId()){
				question.setText(Cq.getText());
			}else if(checkedId==Wh.getId()){
				question.setText(Wh.getText());
			}else
				question.setText(Gz.getText());
		}
	};
}
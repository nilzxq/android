package hlju.edu.SQLiteDemo3410;

public class People {
public int ID=-1;
public String Name;
public int Age;
public float Height;
@Override
public String toString() {
	// TODO Auto-generated method stub
	String result="";
	result+="ID:"+this.ID+","+"姓名："+this.Name+","
			+"年龄"+this.Age+"身高:"+this.Height;
	
	return result;
}

}

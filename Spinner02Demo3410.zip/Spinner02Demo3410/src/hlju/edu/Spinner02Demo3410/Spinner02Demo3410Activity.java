package hlju.edu.Spinner02Demo3410;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Spinner02Demo3410Activity extends Activity {
    /** Called when the activity is first created. */
	TextView view;
	Spinner spinner;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        view=(TextView)findViewById(R.id.view);
        view.setText("��ѡ��������ס�ĳ��У�");
        spinner=(Spinner)findViewById(R.id.city);
        List<String> list=new ArrayList<String>();
        list.add("����");
        list.add("�Ϻ�");
        list.add("����");
        list.add("������");
        list.add("����");
        ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,list);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_item);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(new OnItemSelectedListener(){

			public void onItemSelected(AdapterView<?> arg0, View arg1,
					int arg2, long arg3) {
				// TODO Auto-generated method stub
				String show=(String) spinner.getItemAtPosition(arg2);
				Toast toast=Toast.makeText(Spinner02Demo3410Activity.this, "��ϲ����ѡ����"+show,Toast.LENGTH_LONG);
				toast.setGravity(Gravity.TOP, 0, 220);
				toast.show();
			}
			public void onNothingSelected(AdapterView<?> arg0) {
				// TODO Auto-generated method stub
				
			}
        	
        });
    }
}
package hlju.edu.SubMenuDemo3410;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.SubMenu;
import android.widget.TextView;

public class SubMenuDemo3410Activity extends Activity {
	final static int MENU_00 = Menu.FIRST;
	final static int MENU_01 = Menu.FIRST + 1;
	final static int SUB_MENU_00_01 = Menu.FIRST + 2;
	final static int SUB_MENU_01_00 = Menu.FIRST + 3;
	final static int SUB_MENU_01_01 = Menu.FIRST + 4;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		SubMenu sub1 = (SubMenu) menu.addSubMenu(0, MENU_00, 0, "����").setHeaderIcon(R.drawable.pic3);
		sub1.add(0, SUB_MENU_00_01, 0, "��ӡ").setIcon(R.drawable.pic0);
		SubMenu sub2 = (SubMenu) menu.addSubMenu(0, MENU_01, 1, "�½�").setIcon(
				R.drawable.pic1);
		sub2.add(0, SUB_MENU_01_00, 0, "�ʼ�").setIcon(R.drawable.pic2);
		sub2.add(0, SUB_MENU_01_01, 0, "����").setIcon(R.drawable.pic4);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		TextView label=(TextView)findViewById(R.id.label);
		switch(item.getItemId()){
		case MENU_00:
			label.setText("����");
			return  true;
		case SUB_MENU_00_01:
			label.setText("��ӡ");
			return  true;
		case MENU_01:
			label.setText("�½�");
			return  true;
		case SUB_MENU_01_00:
			label.setText("�ʼ�");
			return  true;
		case SUB_MENU_01_01:
			label.setText("����");
			return  true;
		}
		return false;
	}

}

package hlju.edu.TabDemo3410;

import android.app.Activity;
import android.app.TabActivity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.widget.TabHost;

public class TabDemo3410Activity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       // setContentView(R.layout.main);
        TabHost tabHost=getTabHost();
        LayoutInflater.from(this).inflate(R.layout.tab1,tabHost.getTabContentView(),true);
        LayoutInflater.from(this).inflate(R.layout.tab2,tabHost.getTabContentView(),true);
        LayoutInflater.from(this).inflate(R.layout.tab3,tabHost.getTabContentView(),true);
        LayoutInflater.from(this).inflate(R.layout.tab4,tabHost.getTabContentView(),true);
        tabHost.addTab(tabHost.newTabSpec("TAB1").setIndicator("���Բ���").setContent(R.id.linerlayout));
        tabHost.addTab(tabHost.newTabSpec("TAB2").setIndicator("���Բ���").setContent(R.id.absolutelayout));
        tabHost.addTab(tabHost.newTabSpec("TAB3").setIndicator("��Բ���").setContent(R.id.relativelayout));
        tabHost.addTab(tabHost.newTabSpec("TAB4").setIndicator("���񲼾�").setContent(R.id.TableLayout01));
    }
}
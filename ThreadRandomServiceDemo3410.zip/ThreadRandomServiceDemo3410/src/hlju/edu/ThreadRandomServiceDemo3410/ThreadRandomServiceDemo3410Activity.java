package hlju.edu.ThreadRandomServiceDemo3410;

import hlju.edu.ThreadRandomServiceDemo3410.R;
import hlju.edu.ThreadRandomServiceDemo3410.RAndomservice;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ThreadRandomServiceDemo3410Activity extends Activity {
    /** Called when the activity is first created. */
private static Handler handler= new Handler();
	
	private static TextView mytext;
	private static Button btnstart,btnstop;
	private static double randomDouble;
	
	public static void UpdateGUI(double refreshDouble)
	{
		randomDouble=refreshDouble;
	    handler.post(RefreshLable);
    }
	private static Runnable RefreshLable = new Runnable()
	{
		
		public void run()
		{
			mytext.setText(String.valueOf(randomDouble));
		}
		
	};
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mytext  = (TextView)findViewById(R.id.mytext);
       btnstart = (Button)findViewById(R.id.start);
       btnstop = (Button)findViewById(R.id.stop);
        
        final Intent serviceIntent = new Intent(this,RAndomservice.class);
        btnstart.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				startService(serviceIntent);
				
			}
		});
        btnstop.setOnClickListener(new View.OnClickListener() {
			
			public void onClick(View v) {
				// TODO Auto-generated method stub
				stopService(serviceIntent);
				
			}
		});
        
        
    }
}